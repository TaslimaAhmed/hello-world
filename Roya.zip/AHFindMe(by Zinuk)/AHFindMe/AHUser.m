//
//  AHUser.m
//  AHFindMe
//
//  Created by USSLPC22 on 1/7/17.
//  Copyright © 2017 USSLPC22. All rights reserved.
//

#import "AHUser.h"

@interface AHUser()
@property (nonatomic, copy, readwrite) NSString* ahUserName;
@property (nonatomic, copy, readwrite) NSString* ahUserEmail;
@property (nonatomic, copy, readwrite) NSString* ahUserPassword;
@property (nonatomic, copy, readwrite) NSString* ahUserAddress;
@end


NSString * const AHUserEmailKey = @"kAHUserEmailKey";
NSString * const AHUserPasswordKey = @"kAHUserPasswordKey";

@implementation AHUser
- (instancetype)init {
    self = [super init];
    if (self != nil) {
        self.ahUserName = nil;
        self.ahUserEmail = nil;
        self.ahUserPassword = nil;
        self.ahUserAddress = nil;
    }
    
    return self;
}

- (void)ahSetName:(NSString* )ahName {
    self.ahUserName = ahName;
}

- (void)ahSetEmail:(NSString* )ahEmail {
    self.ahUserEmail = ahEmail;
}

- (void)ahSetPassword:(NSString* )ahPass {
    self.ahUserPassword = ahPass;
}

- (void)ahSetAddress:(NSString* )ahAddress {
    self.ahUserAddress = ahAddress;
}

+ (void)ahUserStore:(AHUser* )ahUser {
    if (ahUser.ahUserName.length > 0 &&
        ahUser.ahUserEmail > 0 &&
        ahUser.ahUserPassword > 0 &&
        ahUser.ahUserAddress.length > 0) {
        
        NSUserDefaults* userDefault = [NSUserDefaults standardUserDefaults];
        [userDefault setValue:ahUser.ahUserEmail forKey:AHUserEmailKey];
        [userDefault setValue:ahUser.ahUserPassword forKey:AHUserPasswordKey];
    }
}

+ (BOOL)ahIsValid:(AHUser* )ahUser {
    NSUserDefaults* userDefault = [NSUserDefaults standardUserDefaults];
    NSString* ahEmail = [userDefault objectForKey:AHUserEmailKey];
    NSString* ahPassword = [userDefault objectForKey:AHUserPasswordKey];
    
    NSLog(@"%@ %@", ahEmail, ahPassword);
    if (ahEmail.length > 0 && [ahEmail isEqualToString:ahUser.ahUserEmail] &&
        ahPassword.length > 0 && [ahEmail isEqualToString:ahUser.ahUserPassword]) {
        return YES;
    }
    return NO;
}

@end
