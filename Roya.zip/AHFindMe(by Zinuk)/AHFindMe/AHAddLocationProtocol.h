//
//  AHAddLocationProtocol.h
//  AHFindMe
//
//  Created by USSLPC22 on 1/14/17.
//  Copyright © 2017 USSLPC22. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <MapKit/MapKit.h>

@protocol AHAddLocationProtocol <NSObject>
@required
- (void)ahAddAnnotation:(MKPointAnnotation* )annotation;
@end
