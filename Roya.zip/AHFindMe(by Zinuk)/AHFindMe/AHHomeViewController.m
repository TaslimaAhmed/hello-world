//
//  AHHomeViewController.m
//  AHFindMe
//
//  Created by USSLPC22 on 1/8/17.
//  Copyright © 2017 USSLPC22. All rights reserved.
//

#import "AHHomeViewController.h"
#import <MapKit/MapKit.h>
#import "AHConstant.h"
#import "AHAddLocationViewController.h"

@interface AHHomeViewController ()<MKMapViewDelegate, UITableViewDataSource, AHAddLocationProtocol>
@property (strong, nonatomic) MKMapView *ahMapView;
@property (strong, nonatomic) UITableView *ahTableView;
@property (strong, nonatomic) NSMutableArray<MKPointAnnotation*>* ahAnnotations;
@end

static NSString *cellIdentifier = @"AHHomeViewControllerCell";

@implementation AHHomeViewController

- (void)dealloc {
    self.ahMapView = nil;
    self.ahTableView = nil;
    self.ahAnnotations = nil;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = kAHOFF_WHITE_COLOR;
    self.navigationController.navigationBar.hidden = FALSE;
    
    [self ahSetupViews];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

- (void)ahSetupViews {
    [self ahSetupNavItems];
    [self ahSetupTableView];
    [self ahSetupMapView];
}

- (void)ahSetupNavItems {
    self.navigationItem.hidesBackButton = YES;
    
    UISegmentedControl *ahSegController = [[UISegmentedControl alloc] initWithItems:@[@"Map", @"List"]];
    [ahSegController addTarget:self action:@selector(ahSwitchOverViews:) forControlEvents:UIControlEventValueChanged];
    ahSegController.selectedSegmentIndex = 0;
    
    self.navigationItem.titleView = ahSegController;
    
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(ahAddNewLocation:)];
    
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"LogOut" style:UIBarButtonItemStylePlain target:self action:@selector(ahLogOutUser:)];
}

- (void)ahSetupTableView {
    self.ahTableView = [[UITableView alloc] initWithFrame:self.view.frame style:UITableViewStyleGrouped];
    self.ahTableView.dataSource = self;
    [self.view addSubview:self.ahTableView];
}

- (void)ahSetupMapView {
    self.ahMapView = [[MKMapView alloc] initWithFrame:self.view.frame];
    self.ahMapView.delegate = self;
    self.ahMapView.showsUserLocation = YES;
    self.ahMapView.mapType = MKMapTypeSatelliteFlyover;
    [self.view addSubview:self.ahMapView];
    
    [self.ahMapView addAnnotations:self.ahAnnotations];
}

- (void)ahLogOutUser: (UIBarButtonItem*)item {
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)ahAddNewLocation: (UIBarButtonItem*)item {
    AHAddLocationViewController* ahAddLocationViewController = [[AHAddLocationViewController alloc] init];
    ahAddLocationViewController.delegate = self;
    UINavigationController* ahNavigationController = [[UINavigationController alloc] initWithRootViewController:ahAddLocationViewController];
    [self presentViewController:ahNavigationController animated:YES completion: NULL];
}
- (void)ahSwitchOverViews:(UISegmentedControl *)segmented{
    
    switch(segmented.selectedSegmentIndex) {
        case 0:
            self.ahMapView.hidden = NO;
            self.ahTableView.hidden = YES;
            break;
        case 1:
            self.ahMapView.hidden = YES;
            self.ahTableView.hidden = NO;
            break;
        default:
            break;
    }
    
}

- (NSMutableArray* )ahAnnotations {
    if(_ahAnnotations == nil) {
        _ahAnnotations = [[NSMutableArray alloc] init];
    }
    return _ahAnnotations;
}

#pragma mark --
#pragma mark -- Delegates
- (void)mapView:(MKMapView *)mapView didUpdateUserLocation:(MKUserLocation *)userLocation {
    MKCoordinateRegion region = MKCoordinateRegionMakeWithDistance(userLocation.coordinate, 800, 800);
    [mapView setRegion:[mapView regionThatFits:region] animated:YES];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)theTableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)theTableView numberOfRowsInSection:(NSInteger)section
{
    return self.ahAnnotations.count;
}

- (UITableViewCell *)tableView:(UITableView *)theTableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    UITableViewCell *cell = (UITableViewCell *)[theTableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (cell == nil) {
        cell  =  [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellIdentifier];
    }
    
    MKPointAnnotation* annotation = (MKPointAnnotation*) [self.ahAnnotations objectAtIndex:indexPath.row];
    cell.textLabel.text = annotation.title;
    cell.detailTextLabel.text = [NSString stringWithFormat:@"%@  Coordinate = (%0.2f, %0.2f)", annotation.subtitle, annotation.coordinate.latitude, annotation.coordinate.longitude];
    
    return cell;
}

#pragma mark --
#pragma mark -- Protocol
- (void)ahAddAnnotation:(MKPointAnnotation* )annotation {
    [self.ahAnnotations addObject:annotation];
    [self.ahTableView reloadData];
    [self ahRefreshMapWithAnnotation:annotation];
    
}

- (void)ahRefreshMapWithAnnotation:(MKPointAnnotation* )ahAnnotation {
    MKCoordinateRegion region = MKCoordinateRegionMakeWithDistance(ahAnnotation.coordinate, 0.1, 0.1);
    [self.ahMapView setRegion:[self.ahMapView regionThatFits:region] animated:YES];
    [self.ahMapView addAnnotation:ahAnnotation];

}
@end
