//
//  AHLoginViewController.m
//  AHFindMe
//
//  Created by USSLPC22 on 1/7/17.
//  Copyright © 2017 USSLPC22. All rights reserved.
//

#import "AHLoginViewController.h"
#import "AHUser.h"
#import "AHConstant.h"
#import "AHSignUpViewController.h"
#import "AHHomeViewController.h"

#define kAHLOGINVC_EMAIL_FIELD_TAG 111
#define kAHLOGINVC_PASSWORD_FIELD_TAG 112

@interface AHLoginViewController () <UITextFieldDelegate>
@property (nonatomic, strong) AHUser* ahUser;
@end

@implementation AHLoginViewController

- (void)dealloc {
    self.ahUser = nil;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = kAHOFF_WHITE_COLOR;
    
    self.ahUser = [[AHUser alloc] init];
    
    [self ahSetupViews];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    [self ahHideNavigationBar];
}

- (void)ahHideNavigationBar {
    if (self.navigationController.navigationBar) {
        self.navigationController.navigationBar.hidden = TRUE;
    }
}

- (void)ahSetupViews {
    CGRect mainFrame = [[UIScreen mainScreen] bounds];
    CGSize fieldSize = CGSizeMake(mainFrame.size.width - 60, 44);
    
    UITextField* ahEmailField = [[UITextField alloc] initWithFrame:
                               CGRectMake(30, 150, fieldSize.width, fieldSize.height)];
    ahEmailField.tag = kAHLOGINVC_EMAIL_FIELD_TAG;
    ahEmailField.layer.cornerRadius = 6;
    [ahEmailField.layer setBorderColor:kAHLIGHT_BLUE_COLOR.CGColor];
    [ahEmailField.layer setBorderWidth:1.0];
    ahEmailField.backgroundColor = kAHMILD_BLUE_COLOR;
    ahEmailField.placeholder = @"Email";
    ahEmailField.returnKeyType = UIReturnKeyNext;
    ahEmailField.delegate = self;
    [self.view addSubview:ahEmailField];
    
    UITextField* ahPasswordField = [[UITextField alloc] initWithFrame:
                          CGRectMake(30, (ahEmailField.frame.origin.y + 50), fieldSize.width, fieldSize.height)];
    ahPasswordField.tag = kAHLOGINVC_PASSWORD_FIELD_TAG;
    ahPasswordField.layer.cornerRadius = 6;
    [ahPasswordField.layer setBorderColor:kAHLIGHT_BLUE_COLOR.CGColor];
    [ahPasswordField.layer setBorderWidth:1.0];
    ahPasswordField.backgroundColor = kAHMILD_BLUE_COLOR;
    ahPasswordField.placeholder = @"Password";
    ahPasswordField.secureTextEntry = YES;
    ahPasswordField.returnKeyType = UIReturnKeyDone;
    ahPasswordField.delegate = self;
    [self.view addSubview:ahPasswordField];
    
    
    UIButton *ahLogInButton = [UIButton buttonWithType: UIButtonTypeRoundedRect];
    ahLogInButton.frame = CGRectMake(ahPasswordField.frame.origin. x + 30, ahPasswordField.frame.origin. y + 70, ahPasswordField.frame.size.width - 60, 21);
    [ahLogInButton setTitle:@"LogIn" forState:UIControlStateNormal];
    [ahLogInButton setTitleColor:[UIColor redColor] forState: UIControlStateHighlighted];
    [ahLogInButton addTarget:self action:@selector(ahLoginButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    [ahLogInButton setTitleColor:kAHDEEP_BLUE_COLOR forState: UIControlStateNormal];
    [self.view addSubview:ahLogInButton];
    
    UIButton *ahSignUpButton = [UIButton buttonWithType: UIButtonTypeRoundedRect];
    ahSignUpButton.frame = CGRectMake(ahLogInButton.frame.origin. x, ahLogInButton.frame.origin. y + 40, ahLogInButton.frame.size.width, ahLogInButton.frame.size.height);
    [ahSignUpButton setTitle:@"Sign Up?" forState:UIControlStateNormal];
    [ahSignUpButton addTarget:self action:@selector(ahSignUpButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    [ahSignUpButton setTitleColor:kAHDEEP_BLUE_COLOR forState: UIControlStateHighlighted];
    [ahSignUpButton setTitleColor:[UIColor redColor] forState: UIControlStateNormal];
    [self.view addSubview:ahSignUpButton];
}

- (void)ahLoginButtonAction:(id)sender {
    [self ahUserSuccessCheck];
}

- (void)ahSignUpButtonAction:(id)sender {
    AHSignUpViewController* ahSignUpViewController = [[AHSignUpViewController alloc] init];
    UINavigationController* ahNavigationController = [[UINavigationController alloc] initWithRootViewController:ahSignUpViewController];
    [self presentViewController:ahNavigationController animated:YES completion: NULL];
}


- (void)ahUserSuccessCheck {
    if ([AHUser ahIsValid: self.ahUser]) {
        AHHomeViewController *ahHomeViewController = [[AHHomeViewController alloc] init];
        [self.navigationController pushViewController:ahHomeViewController animated:YES];
    } else {
        
        UIAlertController* allertController = [UIAlertController alertControllerWithTitle:@"Authentication Failure" message: @"Check your Email or Password" preferredStyle: UIAlertControllerStyleAlert];
        
        UIAlertAction* ok = [UIAlertAction actionWithTitle: @"OK" style:UIAlertActionStyleDefault handler:nil];
        [allertController addAction:ok];
        
        [self presentViewController:allertController animated:YES completion:nil];

    }
}

#pragma mark --
#pragma mark -- UITextFieldDelegate

- (void)textFieldDidBeginEditing:(UITextField *)textField{
    if(textField.tag == kAHLOGINVC_EMAIL_FIELD_TAG) {
        [self.ahUser ahSetEmail: @""];
    }
    
    if (textField.tag == kAHLOGINVC_PASSWORD_FIELD_TAG) {
        [self.ahUser ahSetPassword: @""];
    }
}


- (void)textFieldDidEndEditing:(UITextField *)textField {
    if(textField.tag == kAHLOGINVC_EMAIL_FIELD_TAG) {
        [self.ahUser ahSetEmail: textField.text];
    }
    
    if (textField.tag == kAHLOGINVC_PASSWORD_FIELD_TAG) {
        [self.ahUser ahSetPassword: textField.text];
    }
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    if(textField.tag == kAHLOGINVC_EMAIL_FIELD_TAG) {
        [textField resignFirstResponder];
        
        UITextField* ahPasswordField = (UITextField*) [self.view viewWithTag:kAHLOGINVC_PASSWORD_FIELD_TAG];
        if (ahPasswordField != nil) {
            [ahPasswordField becomeFirstResponder];
        }
    }
    
    if (textField.tag == kAHLOGINVC_PASSWORD_FIELD_TAG) {
        [textField resignFirstResponder];
        [self ahUserSuccessCheck];
    }
    
    return YES;
}
@end
