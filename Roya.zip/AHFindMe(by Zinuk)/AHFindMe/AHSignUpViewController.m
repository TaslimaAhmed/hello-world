//
//  AHSignUpViewController.m
//  AHFindMe
//
//  Created by USSLPC22 on 1/7/17.
//  Copyright © 2017 USSLPC22. All rights reserved.
//

#import "AHSignUpViewController.h"
#import "AHConstant.h"
#import "AHUser.h"


#define kAHSIGNINVC_NAME_FIELD_TAG 112
#define kAHSIGNINVC_EMAIL_FIELD_TAG 113
#define kAHSIGNINVC_PASSWORD_FIELD_TAG 114
#define kAHSIGNINVC_ADDRESS_VIEW_TAG 115



@interface AHSignUpViewController () <UITextFieldDelegate, UITextViewDelegate>
@property (nonatomic, strong) AHUser* ahUser;
@end

@implementation AHSignUpViewController

- (void)dealloc {
    self.ahUser = nil;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = kAHOFF_WHITE_COLOR;
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemCancel target:self action:@selector(ahDismissViewController:)];
    
    self.ahUser = [[AHUser alloc] init];
    
    [self ahSetupViews];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)ahSetupViews {
    CGRect mainFrame = [[UIScreen mainScreen] bounds];
    CGSize fieldSize = CGSizeMake(mainFrame.size.width - 60, 44);
    
    UITextField* ahNameField = [[UITextField alloc] initWithFrame:
                                 CGRectMake(30, 100, fieldSize.width, fieldSize.height)];
    ahNameField.tag = kAHSIGNINVC_NAME_FIELD_TAG;
    ahNameField.layer.cornerRadius = 6;
    [ahNameField.layer setBorderColor:kAHLIGHT_BLUE_COLOR.CGColor];
    [ahNameField.layer setBorderWidth:1.0];
    ahNameField.backgroundColor = kAHMILD_BLUE_COLOR;
    ahNameField.placeholder = @"Full Name";
    ahNameField.returnKeyType = UIReturnKeyNext;
    ahNameField.delegate = self;
    [self.view addSubview:ahNameField];
    
    UITextField* ahEmailField = [[UITextField alloc] initWithFrame:
                                CGRectMake(30, (ahNameField.frame.origin.y + 50), fieldSize.width, fieldSize.height)];
    ahEmailField.tag = kAHSIGNINVC_EMAIL_FIELD_TAG;
    ahEmailField.layer.cornerRadius = 6;
    [ahEmailField.layer setBorderColor:kAHLIGHT_BLUE_COLOR.CGColor];
    [ahEmailField.layer setBorderWidth:1.0];
    ahEmailField.backgroundColor = kAHMILD_BLUE_COLOR;
    ahEmailField.placeholder = @"Email";
    ahEmailField.returnKeyType = UIReturnKeyNext;
    ahEmailField.delegate = self;
    [self.view addSubview:ahEmailField];
    
    
    UITextField* ahPasswordField = [[UITextField alloc] initWithFrame:
                                CGRectMake(30, (ahEmailField.frame.origin.y + 50), fieldSize.width, fieldSize.height)];
    ahPasswordField.tag = kAHSIGNINVC_PASSWORD_FIELD_TAG;
    ahPasswordField.layer.cornerRadius = 6;
    [ahPasswordField.layer setBorderColor:kAHLIGHT_BLUE_COLOR.CGColor];
    [ahPasswordField.layer setBorderWidth:1.0];
    ahPasswordField.secureTextEntry = YES;
    ahPasswordField.backgroundColor = kAHMILD_BLUE_COLOR;
    ahPasswordField.placeholder = @"Password";
    ahPasswordField.returnKeyType = UIReturnKeyNext;
    ahPasswordField.delegate = self;
    [self.view addSubview:ahPasswordField];
    

    UITextView* ahAddressView = [[UITextView alloc] initWithFrame:CGRectMake(30, ahPasswordField.frame.origin. y + 50, ahPasswordField.frame.size.width, 90)];
    ahAddressView.tag = kAHSIGNINVC_ADDRESS_VIEW_TAG;
    ahAddressView.layer.cornerRadius = 6;
    [ahAddressView.layer setBorderColor:kAHLIGHT_BLUE_COLOR.CGColor];
    [ahAddressView.layer setBorderWidth:1.0];
    ahAddressView.backgroundColor = kAHMILD_BLUE_COLOR;
    ahAddressView.returnKeyType = UIReturnKeyDone;
    ahAddressView.delegate = self;
    [self.view addSubview:ahAddressView];
    
    
    UIButton *ahSignUpButton = [UIButton buttonWithType: UIButtonTypeRoundedRect];
    ahSignUpButton.frame = CGRectMake(ahAddressView.frame.origin. x +  30, ahAddressView.frame.origin. y +  (ahAddressView.frame.size.height + 20), ahPasswordField.frame.size.width - 60, 21);
    [ahSignUpButton setTitle:@"Submit" forState:UIControlStateNormal];
    [ahSignUpButton setTitleColor:[UIColor redColor] forState: UIControlStateHighlighted];
    [ahSignUpButton addTarget:self action:@selector(ahSaveUserInfo) forControlEvents:UIControlEventTouchUpInside];
    [ahSignUpButton setTitleColor:kAHDEEP_BLUE_COLOR forState: UIControlStateNormal];
    [self.view addSubview:ahSignUpButton];
}


- (void)ahDismissViewController:(id)sender {
    [self dismissViewControllerAnimated:YES completion:NULL];
}


- (void)ahSaveUserInfo {
    
    [AHUser ahUserStore:self.ahUser];
    [self ahDismissViewController: nil];
}

#pragma mark --
#pragma mark -- UITextFieldDelegate

- (void)textFieldDidBeginEditing:(UITextField *)textField {
    if(textField.tag == kAHSIGNINVC_NAME_FIELD_TAG) {
        [self.ahUser ahSetName: @""];
    }
    
    if (textField.tag == kAHSIGNINVC_EMAIL_FIELD_TAG) {
        [self.ahUser ahSetEmail: @""];
    }
    
    if (textField.tag == kAHSIGNINVC_PASSWORD_FIELD_TAG) {
        [self.ahUser ahSetPassword: @""];
    }
}


- (void)textFieldDidEndEditing:(UITextField *)textField {
    if(textField.tag == kAHSIGNINVC_NAME_FIELD_TAG) {
       [self.ahUser ahSetName:  textField.text];
    }
    
    if (textField.tag == kAHSIGNINVC_EMAIL_FIELD_TAG) {
        [self.ahUser ahSetEmail: textField.text];
    }
    
    if (textField.tag == kAHSIGNINVC_PASSWORD_FIELD_TAG) {
        [self.ahUser ahSetPassword: textField.text];
    }
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    if(textField.tag == kAHSIGNINVC_NAME_FIELD_TAG) {
        [textField resignFirstResponder];
        
        UITextField* ahEmailField = (UITextField*) [self.view viewWithTag:kAHSIGNINVC_EMAIL_FIELD_TAG];
        if (ahEmailField != nil) {
            [ahEmailField becomeFirstResponder];
        }
    }
    
    if (textField.tag == kAHSIGNINVC_EMAIL_FIELD_TAG) {
        [textField resignFirstResponder];
        
        UITextField* ahPasswordField = (UITextField*) [self.view viewWithTag:kAHSIGNINVC_PASSWORD_FIELD_TAG];
        if (ahPasswordField != nil) {
            [ahPasswordField becomeFirstResponder];
        }
    }
    
    if (textField.tag == kAHSIGNINVC_PASSWORD_FIELD_TAG) {
        [textField resignFirstResponder];
        UITextView* ahAddressView = (UITextView*) [self.view viewWithTag:kAHSIGNINVC_ADDRESS_VIEW_TAG];
        if (ahAddressView != nil) {
            [ahAddressView becomeFirstResponder];
        }
    }
    return YES;
}

#pragma mark --
#pragma mark -- UITextFieldDelegate

- (void)textViewDidBeginEditing:(UITextView *)textView {
    [self.ahUser ahSetAddress:@""];
}

- (void)textViewDidEndEditing:(UITextView *)textView {
    [self.ahUser ahSetAddress:textView.text];
}

- (BOOL)textView:(UITextView*)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString*)text {
    if ([text isEqualToString:@"\n"]) {
        [self.ahUser ahSetAddress:textView.text];
        [textView resignFirstResponder];
        [self ahSaveUserInfo];
        return NO;
    }
    return YES;
}
@end
