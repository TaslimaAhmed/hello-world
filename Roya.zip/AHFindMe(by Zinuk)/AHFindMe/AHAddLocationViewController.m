//
//  AHAddLocationViewController.m
//  AHFindMe
//
//  Created by USSLPC22 on 1/8/17.
//  Copyright © 2017 USSLPC22. All rights reserved.
//

#import "AHAddLocationViewController.h"
#import "AHConstant.h"


#define kAHADDLOCATIONVC_TITLE_FIELD_TAG 112
#define kAHADDLOCATIONVC_SUBTITLE_FIELD_TAG 113
#define kAHADDLOCATIONVC_LAT_FIELD_TAG 114
#define kAHADDLOCATIONVC_LON_FIELD_TAG 115

#define kAHADDLOCATIONVC_INVALID_LAT 115
#define kAHADDLOCATIONVC_INVALID_LATLON -200.0




@interface AHAddLocationViewController ()<UITextFieldDelegate>
@property (nonatomic, strong) MKPointAnnotation* ahAnnotation;
@end

@implementation AHAddLocationViewController

- (void)dealloc {
    self.ahAnnotation = nil;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.view.backgroundColor = kAHOFF_WHITE_COLOR;
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemCancel target:self action:@selector(ahDismissViewController:)];
    self.title = @"Add Location";
    
    [self ahSetupViews];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)ahDismissViewController:(id)sender {
    [self dismissViewControllerAnimated:YES completion:NULL];
}

- (void)ahSetupViews {
    CGRect mainFrame = [[UIScreen mainScreen] bounds];
    CGSize fieldSize = CGSizeMake(mainFrame.size.width - 60, 44);
    
    UITextField* ahLocTitleField = [[UITextField alloc] initWithFrame:
                                CGRectMake(30, 100, fieldSize.width, fieldSize.height)];
    ahLocTitleField.tag = kAHADDLOCATIONVC_TITLE_FIELD_TAG;
    ahLocTitleField.layer.cornerRadius = 6;
    [ahLocTitleField.layer setBorderColor:kAHLIGHT_BLUE_COLOR.CGColor];
    [ahLocTitleField.layer setBorderWidth:1.0];
    ahLocTitleField.backgroundColor = kAHMILD_BLUE_COLOR;
    ahLocTitleField.placeholder = @"Enter Place Name";
    ahLocTitleField.returnKeyType = UIReturnKeyNext;
    ahLocTitleField.delegate = self;
    [self.view addSubview:ahLocTitleField];
    
    UITextField* ahLocLatField = [[UITextField alloc] initWithFrame:
                                  CGRectMake(30, (ahLocTitleField.frame.origin.y + 50), fieldSize.width/3, fieldSize.height)];
    ahLocLatField.tag = kAHADDLOCATIONVC_LAT_FIELD_TAG;
    ahLocLatField.layer.cornerRadius = 6;
    [ahLocLatField.layer setBorderColor:kAHLIGHT_BLUE_COLOR.CGColor];
    [ahLocLatField.layer setBorderWidth:1.0];
    ahLocLatField.keyboardType = UIKeyboardTypeDecimalPad;
    ahLocLatField.backgroundColor = kAHMILD_BLUE_COLOR;
    ahLocLatField.placeholder = @"Lattitude";
    ahLocLatField.returnKeyType = UIReturnKeyNext;
    ahLocLatField.delegate = self;
    [self.view addSubview:ahLocLatField];
    
    
    UITextField* ahLocLonField = [[UITextField alloc] initWithFrame:
                                  CGRectMake(fieldSize.width - (fieldSize.width/4), (ahLocTitleField.frame.origin.y + 50), fieldSize.width/3, fieldSize.height)];
    ahLocLonField.tag = kAHADDLOCATIONVC_LON_FIELD_TAG;
    ahLocLonField.layer.cornerRadius = 6;
    [ahLocLonField.layer setBorderColor:kAHLIGHT_BLUE_COLOR.CGColor];
    [ahLocLonField.layer setBorderWidth:1.0];
    ahLocLonField.keyboardType = UIKeyboardTypeDecimalPad;
    ahLocLonField.backgroundColor = kAHMILD_BLUE_COLOR;
    ahLocLonField.placeholder = @"Longitude";
    ahLocLonField.returnKeyType = UIReturnKeyNext;
    ahLocLonField.delegate = self;
    [self.view addSubview:ahLocLonField];
    
    
    UITextField* ahLocSubTitleField = [[UITextField alloc] initWithFrame:
                                 CGRectMake(30, (ahLocLonField.frame.origin.y + 50), fieldSize.width, fieldSize.height)];
    ahLocSubTitleField.tag = kAHADDLOCATIONVC_SUBTITLE_FIELD_TAG;
    ahLocSubTitleField.layer.cornerRadius = 6;
    [ahLocSubTitleField.layer setBorderColor:kAHLIGHT_BLUE_COLOR.CGColor];
    [ahLocSubTitleField.layer setBorderWidth:1.0];
    ahLocSubTitleField.backgroundColor = kAHMILD_BLUE_COLOR;
    ahLocSubTitleField.placeholder = @"Place Category";
    ahLocSubTitleField.returnKeyType = UIReturnKeyDone;
    ahLocSubTitleField.delegate = self;
    [self.view addSubview:ahLocSubTitleField];
    
    
    
    UIButton *ahSubmitButton = [UIButton buttonWithType: UIButtonTypeRoundedRect];
    ahSubmitButton.frame = CGRectMake(ahLocSubTitleField.frame.origin. x +  30, ahLocSubTitleField.frame.origin. y +  (ahLocSubTitleField.frame.size.height + 20), ahLocSubTitleField.frame.size.width - 60, 21);
    [ahSubmitButton setTitle:@"Submit" forState:UIControlStateNormal];
    [ahSubmitButton setTitleColor:[UIColor redColor] forState: UIControlStateHighlighted];
    [ahSubmitButton addTarget:self action:@selector(ahSubmitLocationActin:) forControlEvents:UIControlEventTouchUpInside];
    [ahSubmitButton setTitleColor:kAHDEEP_BLUE_COLOR forState: UIControlStateNormal];
    [self.view addSubview:ahSubmitButton];
}


- (void)ahSubmitLocationActin:(UIButton* )sender {
    
    if ([self.delegate respondsToSelector:@selector(ahAddAnnotation:)] &&
          CLLocationCoordinate2DIsValid(self.ahAnnotation.coordinate)) {
        
        __weak AHAddLocationViewController* weakSelf = self;
        [self dismissViewControllerAnimated:YES completion:^ {
            [weakSelf.delegate ahAddAnnotation:weakSelf.ahAnnotation];
        }];
    }
}

- (MKPointAnnotation* )ahAnnotation {
    if(_ahAnnotation == nil) {
        _ahAnnotation = [[MKPointAnnotation alloc] init];
    }
    return _ahAnnotation;
}


#pragma mark --
#pragma mark -- UITextFieldDelegate


- (void)textFieldDidBeginEditing:(UITextField *)textField {
    if(textField.tag == kAHADDLOCATIONVC_TITLE_FIELD_TAG) {
        self.ahAnnotation.title = @"";
    }
    
    if (textField.tag == kAHADDLOCATIONVC_LAT_FIELD_TAG) {
        [self.ahAnnotation setCoordinate:CLLocationCoordinate2DMake(kAHADDLOCATIONVC_INVALID_LATLON, self.ahAnnotation.coordinate.longitude)];
    }
    
    if (textField.tag == kAHADDLOCATIONVC_LON_FIELD_TAG) {
        [self.ahAnnotation setCoordinate:CLLocationCoordinate2DMake(self.ahAnnotation.coordinate.latitude, kAHADDLOCATIONVC_INVALID_LATLON)];
    }
    
    if (textField.tag == kAHADDLOCATIONVC_SUBTITLE_FIELD_TAG) {
        self.ahAnnotation.subtitle = @"";
    }
}


- (void)textFieldDidEndEditing:(UITextField *)textField {
    if(textField.tag == kAHADDLOCATIONVC_TITLE_FIELD_TAG) {
        self.ahAnnotation.title = textField.text;
    }
    
    if (textField.tag == kAHADDLOCATIONVC_LAT_FIELD_TAG) {
        [self.ahAnnotation setCoordinate:CLLocationCoordinate2DMake(textField.text.doubleValue, self.ahAnnotation.coordinate.longitude)];
    }
    
    if (textField.tag == kAHADDLOCATIONVC_LON_FIELD_TAG) {
        [self.ahAnnotation setCoordinate:CLLocationCoordinate2DMake(self.ahAnnotation.coordinate.latitude, textField.text.doubleValue)];
    }
    
    if (textField.tag == kAHADDLOCATIONVC_SUBTITLE_FIELD_TAG) {
        self.ahAnnotation.subtitle = textField.text;
    }
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    if(textField.tag == kAHADDLOCATIONVC_TITLE_FIELD_TAG) {
        [textField resignFirstResponder];
        
        UITextField* ahLocLatField = (UITextField*) [self.view viewWithTag:kAHADDLOCATIONVC_LAT_FIELD_TAG];
        if (ahLocLatField != nil) {
            [ahLocLatField becomeFirstResponder];
        }
    }
    
    if (textField.tag == kAHADDLOCATIONVC_LAT_FIELD_TAG) {
        [textField resignFirstResponder];
        
        UITextField* ahLocLonField = (UITextField*) [self.view viewWithTag:kAHADDLOCATIONVC_LON_FIELD_TAG];
        if (ahLocLonField != nil) {
            [ahLocLonField becomeFirstResponder];
        }
    }
    
    if (textField.tag == kAHADDLOCATIONVC_LON_FIELD_TAG) {
        [textField resignFirstResponder];
        UITextField* ahLocSubTitleField = (UITextField*) [self.view viewWithTag:kAHADDLOCATIONVC_SUBTITLE_FIELD_TAG];
        if (ahLocSubTitleField != nil) {
            [ahLocSubTitleField becomeFirstResponder];
        }
    }
    
    if (textField.tag == kAHADDLOCATIONVC_SUBTITLE_FIELD_TAG) {
        [textField resignFirstResponder];
        
        [self ahSubmitLocationActin:nil];
    }
    return YES;
}

@end
