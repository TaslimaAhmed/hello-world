//
//  AHConstant.h
//  AHFindMe
//
//  Created by USSLPC22 on 1/7/17.
//  Copyright © 2017 USSLPC22. All rights reserved.
//

#ifndef Constant_h
#define Constant_h

#define kAHDEEP_BLUE_COLOR [UIColor colorWithRed:(59.0/255.0) green:(89.0/255.0) blue:(152.0/255.0) alpha:1.0]
#define kAHLIGHT_BLUE_COLOR [UIColor colorWithRed:(139.0/255.0) green:(157.0/255.0) blue:(195.0/255.0) alpha:1.0]

#define kAHMILD_BLUE_COLOR [UIColor colorWithRed:(223.0/255.0) green:(227.0/255.0) blue:(238.0/255.0) alpha:1.0]

#define kAHOFF_WHITE_COLOR [UIColor colorWithRed:(247.0/255.0) green:(247.0/255.0) blue:(247.0/255.0) alpha:1.0]


#endif /* Constant_h */
