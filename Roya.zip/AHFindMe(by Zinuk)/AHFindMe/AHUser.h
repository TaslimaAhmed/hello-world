//
//  AHUser.h
//  AHFindMe
//
//  Created by USSLPC22 on 1/7/17.
//  Copyright © 2017 USSLPC22. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AHUser : NSObject
@property (nonatomic, readonly) NSString* ahUserName;
@property (nonatomic, readonly) NSString* ahUserEmail;
@property (nonatomic, readonly) NSString* ahUserPassword;
@property (nonatomic, readonly) NSString* ahUserAddress;

- (void)ahSetName:(NSString* )ahName;
- (void)ahSetEmail:(NSString* )ahEmail;
- (void)ahSetPassword:(NSString* )ahPass;
- (void)ahSetAddress:(NSString* )ahAddress;

+ (void)ahUserStore:(AHUser* )ahUser;
+ (BOOL)ahIsValid:(AHUser* )ahUser;
@end
